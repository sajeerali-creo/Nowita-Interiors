<?php
/**
 * The template for displaying all single posts and attachments
 *
 * @package WordPress
 * @subpackage Twenty_Sixteen
 * @since Twenty Sixteen 1.0
 */
?>
<?php get_header(); ?>

<section class="bg-detail">
  
    <div class="container">
      <div class="col s12 padding-top-20">
        <div class="left-area">
          <h2><?php echo get_the_title(); ?></h2>
          <span><i class="zmdi zmdi-calendar-alt"></i>&nbsp;&nbsp;<?php the_time('l, F jS, Y') ?></span>
        </div>
        <div class="right-area">
          <a href="index.html">
            <i class="zmdi zmdi-close-circle"></i>
          </a>
        </div>
      </div>
      <div class="row">
        <div class="col s12">
          <div class="box-detail">
            <div class="col s12 m9 l9">
              <?php the_post_thumbnail('full',array("class"=>"img_fit")); ?>
              <!-- each image -->
                <div class="row">
                  <div class="each-pic">
                         <div id="primary" class="content-area">
                              <div id="content" class="site-content" role="main">
                           
                                <?php /* The loop */ ?>
                                <?php while ( have_posts() ) : the_post(); ?>
                           
                                  <?php get_template_part( 'content', get_post_format() ); ?>
                                 
                           
                                <?php endwhile; ?>
                           
                              </div><!-- #content -->
                            </div><!-- #primary -->
                       </div>
                </div>
            </div>
            <div class="col s12 m3 l3 border-left">
              <h3>Tags</h3>
              <span>Interior Design</span>
              <span>Design</span>
              <span>Interior</span>
              <span>Color</span>
            </div>
          </div>
        </div>
      </div>
    </div>

</section>
<?php get_footer(); ?>
